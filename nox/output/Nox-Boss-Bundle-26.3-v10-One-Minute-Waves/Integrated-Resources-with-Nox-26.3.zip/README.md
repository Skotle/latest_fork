# Integrated Resource Pack

Sources:
- Stellarity-5.4.2/assets
- UltimateWarden-RP-0.3.S7.zip
- blue_depths Resourcepack v1.1.0.zip
- BACAP Language Pack 1.20.0.1.zip
- Ancient Artifacts 2 Resourcepack V2.5.2a (datapack translations)

Fixes included:
- Forward-slash zip paths for Minecraft resource loading.
- Fallback item model definitions for Stellarity bell_flower, chorus_petal, and goosh.
- Alias texture for stellarity:block/ender_grass_block_snow.
- Normalized BACAP language files into strict JSON.
- Merged Ancient Artifacts 2 translation keys into each matching language file.
