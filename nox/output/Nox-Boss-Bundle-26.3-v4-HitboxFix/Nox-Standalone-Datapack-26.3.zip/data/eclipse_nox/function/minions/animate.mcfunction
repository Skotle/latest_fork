execute store result score @s nx.dx run data get entity @s Pos[0] 100
execute store result score @s nx.dz run data get entity @s Pos[2] 100
execute unless entity @s[tag=nox.animated] run scoreboard players operation @s nx.mx = @s nx.dx
execute unless entity @s[tag=nox.animated] run scoreboard players operation @s nx.mz = @s nx.dz
execute unless entity @s[tag=nox.animated] run scoreboard players set @s nx.add 0
tag @s add nox.animated
scoreboard players set #mode nx.add 0
execute unless score @s nx.dx = @s nx.mx run scoreboard players set #mode nx.add 1
execute unless score @s nx.dz = @s nx.mz run scoreboard players set #mode nx.add 1
execute if entity @a[tag=nox.active,distance=..2.7] run scoreboard players set #mode nx.add 2
scoreboard players operation @s nx.mx = @s nx.dx
scoreboard players operation @s nx.mz = @s nx.dz
scoreboard players add @s nx.add 1
execute if score @s nx.add matches 32.. run scoreboard players set @s nx.add 0
scoreboard players operation #frame nx.add = @s nx.add
scoreboard players set #two nx.add 2
scoreboard players operation #frame nx.add /= #two nx.add
data modify storage eclipse_nox:minion rotation set from entity @s Rotation
function eclipse_nox:minions/select
execute as @e[tag=nox.selected] run data modify entity @s Rotation set from storage eclipse_nox:minion rotation
execute if score #mode nx.add matches 0 if score #frame nx.add matches 0 run function eclipse_nox:minions/pose/idle/0
execute if score #mode nx.add matches 0 if score #frame nx.add matches 1 run function eclipse_nox:minions/pose/idle/1
execute if score #mode nx.add matches 0 if score #frame nx.add matches 2 run function eclipse_nox:minions/pose/idle/2
execute if score #mode nx.add matches 0 if score #frame nx.add matches 3 run function eclipse_nox:minions/pose/idle/3
execute if score #mode nx.add matches 0 if score #frame nx.add matches 4 run function eclipse_nox:minions/pose/idle/4
execute if score #mode nx.add matches 0 if score #frame nx.add matches 5 run function eclipse_nox:minions/pose/idle/5
execute if score #mode nx.add matches 0 if score #frame nx.add matches 6 run function eclipse_nox:minions/pose/idle/6
execute if score #mode nx.add matches 0 if score #frame nx.add matches 7 run function eclipse_nox:minions/pose/idle/7
execute if score #mode nx.add matches 0 if score #frame nx.add matches 8 run function eclipse_nox:minions/pose/idle/8
execute if score #mode nx.add matches 0 if score #frame nx.add matches 9 run function eclipse_nox:minions/pose/idle/9
execute if score #mode nx.add matches 0 if score #frame nx.add matches 10 run function eclipse_nox:minions/pose/idle/10
execute if score #mode nx.add matches 0 if score #frame nx.add matches 11 run function eclipse_nox:minions/pose/idle/11
execute if score #mode nx.add matches 0 if score #frame nx.add matches 12 run function eclipse_nox:minions/pose/idle/12
execute if score #mode nx.add matches 0 if score #frame nx.add matches 13 run function eclipse_nox:minions/pose/idle/13
execute if score #mode nx.add matches 0 if score #frame nx.add matches 14 run function eclipse_nox:minions/pose/idle/14
execute if score #mode nx.add matches 0 if score #frame nx.add matches 15 run function eclipse_nox:minions/pose/idle/15
execute if score #mode nx.add matches 1 if score #frame nx.add matches 0 run function eclipse_nox:minions/pose/walk/0
execute if score #mode nx.add matches 1 if score #frame nx.add matches 1 run function eclipse_nox:minions/pose/walk/1
execute if score #mode nx.add matches 1 if score #frame nx.add matches 2 run function eclipse_nox:minions/pose/walk/2
execute if score #mode nx.add matches 1 if score #frame nx.add matches 3 run function eclipse_nox:minions/pose/walk/3
execute if score #mode nx.add matches 1 if score #frame nx.add matches 4 run function eclipse_nox:minions/pose/walk/4
execute if score #mode nx.add matches 1 if score #frame nx.add matches 5 run function eclipse_nox:minions/pose/walk/5
execute if score #mode nx.add matches 1 if score #frame nx.add matches 6 run function eclipse_nox:minions/pose/walk/6
execute if score #mode nx.add matches 1 if score #frame nx.add matches 7 run function eclipse_nox:minions/pose/walk/7
execute if score #mode nx.add matches 1 if score #frame nx.add matches 8 run function eclipse_nox:minions/pose/walk/8
execute if score #mode nx.add matches 1 if score #frame nx.add matches 9 run function eclipse_nox:minions/pose/walk/9
execute if score #mode nx.add matches 1 if score #frame nx.add matches 10 run function eclipse_nox:minions/pose/walk/10
execute if score #mode nx.add matches 1 if score #frame nx.add matches 11 run function eclipse_nox:minions/pose/walk/11
execute if score #mode nx.add matches 1 if score #frame nx.add matches 12 run function eclipse_nox:minions/pose/walk/12
execute if score #mode nx.add matches 1 if score #frame nx.add matches 13 run function eclipse_nox:minions/pose/walk/13
execute if score #mode nx.add matches 1 if score #frame nx.add matches 14 run function eclipse_nox:minions/pose/walk/14
execute if score #mode nx.add matches 1 if score #frame nx.add matches 15 run function eclipse_nox:minions/pose/walk/15
execute if score #mode nx.add matches 2 if score #frame nx.add matches 0 run function eclipse_nox:minions/pose/attack/0
execute if score #mode nx.add matches 2 if score #frame nx.add matches 1 run function eclipse_nox:minions/pose/attack/1
execute if score #mode nx.add matches 2 if score #frame nx.add matches 2 run function eclipse_nox:minions/pose/attack/2
execute if score #mode nx.add matches 2 if score #frame nx.add matches 3 run function eclipse_nox:minions/pose/attack/3
execute if score #mode nx.add matches 2 if score #frame nx.add matches 4 run function eclipse_nox:minions/pose/attack/4
execute if score #mode nx.add matches 2 if score #frame nx.add matches 5 run function eclipse_nox:minions/pose/attack/5
execute if score #mode nx.add matches 2 if score #frame nx.add matches 6 run function eclipse_nox:minions/pose/attack/6
execute if score #mode nx.add matches 2 if score #frame nx.add matches 7 run function eclipse_nox:minions/pose/attack/7
execute if score #mode nx.add matches 2 if score #frame nx.add matches 8 run function eclipse_nox:minions/pose/attack/8
execute if score #mode nx.add matches 2 if score #frame nx.add matches 9 run function eclipse_nox:minions/pose/attack/9
execute if score #mode nx.add matches 2 if score #frame nx.add matches 10 run function eclipse_nox:minions/pose/attack/10
execute if score #mode nx.add matches 2 if score #frame nx.add matches 11 run function eclipse_nox:minions/pose/attack/11
execute if score #mode nx.add matches 2 if score #frame nx.add matches 12 run function eclipse_nox:minions/pose/attack/12
execute if score #mode nx.add matches 2 if score #frame nx.add matches 13 run function eclipse_nox:minions/pose/attack/13
execute if score #mode nx.add matches 2 if score #frame nx.add matches 14 run function eclipse_nox:minions/pose/attack/14
execute if score #mode nx.add matches 2 if score #frame nx.add matches 15 run function eclipse_nox:minions/pose/attack/15
