function eclipse_nox:minions/select
execute as @e[tag=nox.selected] run tp @s ~ ~ ~
tag @e[tag=nox.selected] add nox.riding
