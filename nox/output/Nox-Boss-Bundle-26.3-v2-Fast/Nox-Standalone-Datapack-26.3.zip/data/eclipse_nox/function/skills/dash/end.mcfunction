kill @e[tag=nox.target]
scoreboard players set #safe nx.safe 30
scoreboard players set #next nx.next 5
scoreboard players set #expose nx.expose 1
execute if score #crash nx.move matches 1 run scoreboard players set #safe nx.safe 35
scoreboard players set #crash nx.move 0
tellraw @a[tag=nox.member] {"text": "균형 붕괴 — 녹스의 심장 노출! 지금 공격하면 피해가 1.5배.", "color": "gold"}
