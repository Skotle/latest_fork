scoreboard players add #adds nx.add 1
execute if score #adds nx.add matches 100.. run function eclipse_nox:minions/reinforce
tag @e[tag=nox.minion_visual] remove nox.riding
execute as @e[tag=nox.minion] on passengers run tag @s add nox.riding
kill @e[tag=nox.minion_visual,tag=!nox.riding]
execute as @e[tag=nox.minion_visual] at @s run particle minecraft:soul ~ ~.5 ~ .1 .2 .1 .01 1 normal @a[tag=nox.member]
execute as @e[tag=nox.minion] at @s unless entity @e[tag=nox.anchor,tag=nox.current,distance=..23] run tp @s ~ ~ ~ facing entity @e[tag=nox.anchor,tag=nox.current,limit=1] feet
execute as @e[tag=nox.minion] at @s unless entity @e[tag=nox.anchor,tag=nox.current,distance=..24] at @e[tag=nox.anchor,tag=nox.current,limit=1] run tp @s ~ ~ ~
