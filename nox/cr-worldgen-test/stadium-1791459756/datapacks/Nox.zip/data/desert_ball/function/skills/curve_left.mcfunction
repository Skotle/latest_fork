function desert_ball:skills/shoot
tag @e[tag=db.shot,sort=nearest,limit=1] add db.curve_left
