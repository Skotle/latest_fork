execute if score #state db.state matches 0 run function eclipse_nox:fight/start_nox
