ItemEvents.modifyTooltips(event => {
    event.add('kubejs:ender_eye', 'The powers of the Eye of Ender have been depleted from this dimension.')
    event.add('minecraft:ender_eye', 'An artificial eye engineered to mimic the powers of the Eye of Ender.')

    event.add('#astages:copycats', '§bResearch: §eCopycat Blocks')

    event.add('#astages:diving_equipment_mk1', '§6Milestone: §eCopper Diving Equipment')
    event.add('#astages:machines_mk1', '§6Milestone: §eBasic Machinery')
    event.add('#astages:contraptions_mk1', '§6Milestone: §eContraptions')
    event.add('#astages:rotational_power_generation_mk1', '§6Milestone: §eRotational Power Generation')
    event.add('#astages:rotational_power_transportation_mk1', '§6Milestone: §eRotational Power Transportation')
    event.add('#astages:logistics_mk1', '§6Milestone: §eLogistics')

    // ==================== Stage 2 ====================

    event.add('#astages:machines_mk2', '§6Milestone: §eAdvanced Processing')
    event.add('#astages:super_heating', '§6Milestone: §eSuper Heating')
    event.add('#astages:blueprints_mk1', '§6Milestone: §eSchematics')
    event.add('#astages:fluids_mk1', '§6Milestone: §eFluids')
    event.add('#astages:advanced_redstone_mk1', '§6Milestone: §eAdvanced Redstone')
    event.add('#astages:post_production', '§6Milestone: §ePost Production')

    // ==================== Stage 3 ====================

    event.add('#astages:brass_production', '§6Milestone: §eAdvanced Crafting')
    event.add('#astages:advanced_redstone_mk2', '§6Milestone: §eSmart Redstone')
    event.add('#astages:better_item_managment', '§6Milestone: §eBetter Item Managment')
    event.add('#astages:advanced_fluids', '§6Milestone: §eBetter Fluids')
    event.add('#astages:logistics_mk3', '§6Milestone: §eBetter Logistics')
    event.add('#astages:moving_contraptions_mk2', '§6Milestone: §eMore Contraptions')

    // ==================== Stage 4 ====================

    event.add('#astages:steam_power_generation', '§6Milestone: §eSteam Components')
    event.add('#astages:machines_mk4', '§6Milestone: §eSequenced Machinery')
    event.add('#astages:trains', '§6Milestone: §eTrains')
    event.add('#astages:advanced_machining', '§6Milestone: §eAdvanced Machining')
    event.add('#astages:better_equipment', '§6Milestone: §eSmart Equipment')
    event.add('#astages:vehicle_components', '§6Milestone: §eVehicle Components')
    event.add('#astages:economy', '§6Milestone: §eEconomy')

    // ==================== Stage 5 ====================

    event.add('#astages:diesel_power_generation', '§6Milestone: §eDiesel Power Generation')
    event.add('#astages:oil', '§6Milestone: §eOil Production')
    event.add('#astages:advanced_farming', '§6Milestone: §eAdvanced Farming')
    event.add('#astages:electricity', '§6Milestone: §eElectricity')
    event.add('#astages:hypertubes', '§6Milestone: §eHypertubes')
    event.add('#astages:enchantment_industry', '§6Milestone: §eEnchantment Industry')

    // ==================== Stage 6 ====================

    event.add('#astages:item_sink', '§6Milestone: §eItem Sink')
    event.add('#astages:pattern_schematics', '§6Milestone: §ePattern Schematics')
    event.add('#astages:jetpack_mk1', '§6Milestone: §eJetpack')
    event.add('#astages:chunk_loading', '§6Milestone: §eChunk Loading')
    event.add('#astages:cannons', '§6Milestone: §eCannons')

    // ==================== Stage 7 ====================

    event.add('#astages:automated_trading', '§6Milestone: §eAutomated Trading')
    event.add('#astages:radar_components', '§6Milestone: §eRadar Components')
    event.add('#astages:optical_fabrication', '§6Milestone: §eOptical Fabrication')
    event.add('#astages:engraving', '§6Milestone: §eEngraving')
    event.add('#astages:airship_components', '§6Milestone: §eAirship Components')
    event.add('#astages:astrophotography_gear', '§6Milestone: §eAstrophotography Gear')
    event.add('#astages:mobile_packages', '§6Milestone: §eMobile Packages')

    // ==================== Stage 8 ====================

    event.add('#astages:jetpack_mk2', '§6Milestone: §eNetherite Equipment')
    event.add('#astages:spacecraft_components', '§6Milestone: §eSpacecraft Components')
    event.add('#astages:space_gear', '§6Milestone: §eSpace Gear')
    event.add('#astages:atmospheric_machinery', '§6Milestone: §eAtmospheric Machinery')
    event.add('#astages:gyroscopic_components', '§6Milestone: §eGyroscopic Components')
    event.add('#astages:rocket_propulsion', '§6Milestone: §eRocket Propulsion')

    // ==================== Stage 9 ====================

    event.add('#astages:advanced_power_generation', '§6Milestone: §eAdvanced Power Generation')
    event.add('#astages:lunar_spacecraft_components', '§6Milestone: §eLunar Spacecraft Components')
    event.add('#astages:lunar_atmospheric_machinery', '§6Milestone: §eLunar Atmospheric Machinery')
    event.add('#astages:martian_space_gear', '§6Milestone: §eMartian Space Gear')
    event.add('#astages:mechanical_companion', '§6Milestone: §eAeronautics Automated Logistics')

    // ==================== Stage 10 ====================

    event.add('#astages:nuclear_reactor_components', '§6Milestone: §eNuclear Reactor Components')
    event.add('#astages:createqol', '§6Milestone: §eCreate QoL')
    event.add('#astages:teleportation', '§6Milestone: §eTeleportation')
    event.add('#astages:pocket_dimension', '§6Milestone: §ePocket Dimension')
    event.add('#astages:advanced_teleportation', '§6Milestone: §eAdvanced Teleportation')
    event.add('#astages:advanced_propulsion', '§6Milestone: §eAdvanced Propulsion')

})