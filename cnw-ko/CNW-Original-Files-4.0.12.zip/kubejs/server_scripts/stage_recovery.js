const COPYCATS_DATA = "cnw_stage_copycats"

const STAGE1_DATA = "cnw_stage_stage1"
const DIVING_EQUIPMENT_MK1_DATA = "cnw_stage_diving_equipment_mk1"
const MACHINES_MK1_DATA = "cnw_stage_machines_mk1"
const ROTATIONAL_POWER_GENERATION_MK1_DATA = "cnw_stage_rotational_power_generation_mk1"
const CONTRAPTIONS_MK1_DATA = "cnw_stage_contraptions_mk1"
const ROTATIONAL_POWER_TRANSPORTATION_MK1_DATA = "cnw_stage_rotational_power_transportation_mk1"
const LOGISTICS_MK1_DATA = "cnw_stage_logistics_mk1"

const STAGE2_DATA = "cnw_stage_stage2"
const MACHINES_MK2_DATA = "cnw_stage_machines_mk2"
const SUPER_HEATING_DATA = "cnw_stage_super_heating"
const BLUEPRINTS_MK1_DATA = "cnw_stage_blueprints_mk1"
const FLUIDS_MK1_DATA = "cnw_stage_fluids_mk1"
const ADVANCED_REDSTONE_MK1_DATA = "cnw_stage_advanced_redstone_mk1"
const POST_PRODUCTION_DATA = "cnw_stage_post_production"

const STAGE3_DATA = "cnw_stage_stage3"
const BRASS_PRODUCTION_DATA = "cnw_stage_brass_production"
const ADVANCED_REDSTONE_MK2_DATA = "cnw_stage_advanced_redstone_mk2"
const BETTER_ITEM_MANAGMENT_DATA = "cnw_stage_better_item_managment"
const ADVANCED_FLUIDS_DATA = "cnw_stage_advanced_fluids"
const LOGISTICS_MK3_DATA = "cnw_stage_logistics_mk3"
const MOVING_CONTRAPTIONS_MK2_DATA = "cnw_stage_moving_contraptions_mk2"

const STAGE4_DATA = "cnw_stage_stage4"
const STEAM_POWER_GENERATION_DATA = "cnw_stage_steam_power_generation"
const MACHINES_MK4_DATA = "cnw_stage_machines_mk4"
const TRAINS_DATA = "cnw_stage_trains"
const ADVANCED_MACHINING_DATA = "cnw_stage_advanced_machining"
const BETTER_EQUIPMENT_DATA = "cnw_stage_better_equipment"
const VEHICLE_COMPONENTS_DATA = "cnw_stage_vehicle_components"
const ECONOMY_DATA = "cnw_stage_economy"

const STAGE5_DATA = "cnw_stage_stage5"
const DIESEL_POWER_GENERATION_DATA = "cnw_stage_diesel_power_generation"
const OIL_DATA = "cnw_stage_oil"
const ADVANCED_FARMING_DATA = "cnw_stage_advanced_farming"
const ELECTRICITY_DATA = "cnw_stage_electricity"
const HYPERTUBES_DATA = "cnw_stage_hypertubes"
const ENCHANTMENT_INDUSTRY_DATA = "cnw_stage_enchantment_industry"

const STAGE6_DATA = "cnw_stage_stage6"
const ITEM_SINK_DATA = "cnw_stage_item_sink"
const PATTERN_SCHEMATICS_DATA = "cnw_stage_pattern_schematics"
const JETPACK_MK1_DATA = "cnw_stage_jetpack_mk1"
const CHUNK_LOADING_DATA = "cnw_stage_chunk_loading"
const CANNONS_DATA = "cnw_stage_cannons"

const STAGE7_DATA = "cnw_stage_stage7"
const AUTOMATED_TRADING_DATA = "cnw_stage_automated_trading"
const RADAR_COMPONENTS_DATA = "cnw_stage_radar_components"
const OPTICAL_FABRICATION_DATA = "cnw_stage_optical_fabrication"
const ENGRAVING_DATA = "cnw_stage_engraving"
const AIRSHIP_COMPONENTS_DATA = "cnw_stage_airship_components"
const ASTROPHOTOGRAPHY_GEAR_DATA = "cnw_stage_astrophotography_gear"
const MOBILE_PACKAGES_DATA = "cnw_stage_mobile_packages"

const STAGE8_DATA = "cnw_stage_stage8"
const JETPACK_MK2_DATA = "cnw_stage_jetpack_mk2"
const SPACECRAFT_COMPONENTS_DATA = "cnw_stage_spacecraft_components"
const SPACE_GEAR_DATA = "cnw_stage_space_gear"
const ATMOSPHERIC_MACHINERY_DATA = "cnw_stage_atmospheric_machinery"
const GYROSCOPIC_COMPONENTS_DATA = "cnw_stage_gyroscopic_components"
const ROCKET_PROPULSION_DATA = "cnw_stage_rocket_propulsion"

const STAGE9_DATA = "cnw_stage_stage9"
const NUCLEAR_REACTOR_COMPONENTS_DATA = "cnw_stage_nuclear_reactor_components"
const ADVANCED_POWER_GENERATION_DATA = "cnw_stage_advanced_power_generation"
const LUNAR_SPACECRAFT_COMPONENTS_DATA = "cnw_stage_lunar_spacecraft_components"
const LUNAR_ATMOSPHERIC_MACHINERY_DATA = "cnw_stage_lunar_atmospheric_machinery"
const MARTIAN_SPACE_GEAR_DATA = "cnw_stage_martian_space_gear"
const MECHANICAL_COMPANION_DATA = "cnw_stage_mechanical_companion"

const STAGE10_DATA = "cnw_stage_stage10"
const CREATEQOL_DATA = "cnw_stage_createqol"
const TELEPORTATION_DATA = "cnw_stage_teleportation"
const POCKET_DIMENSION_DATA = "cnw_stage_pocket_dimension"
const ADVANCED_TELEPORTATION_DATA = "cnw_stage_advanced_teleportation"
const ADVANCED_PROPULSION_DATA = "cnw_stage_advanced_propulsion"

function restoreCopycats(player) {

    if (!player.persistentData.getBoolean(COPYCATS_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "copycats")) {
        return
    }

    AStages.addStageToPlayer(player, "copycats")

    console.info(
        "[STAGE RECOVERY] RESTORED copycats TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §ecopycats §fstage has been restored."
    )
}


function restoreStage1(player) {

    if (!player.persistentData.getBoolean(STAGE1_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "stage1")) {
        return
    }

    AStages.addStageToPlayer(player, "stage1")

    console.info(
        "[STAGE RECOVERY] RESTORED stage1 TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §estage1 §fstage has been restored."
    )
}


function restoreDivingEquipmentMk1(player) {

    if (!player.persistentData.getBoolean(DIVING_EQUIPMENT_MK1_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "diving_equipment_mk1")) {
        return
    }

    AStages.addStageToPlayer(player, "diving_equipment_mk1")

    console.info(
        "[STAGE RECOVERY] RESTORED diving_equipment_mk1 TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §ediving_equipment_mk1 §fstage has been restored."
    )
}


function restoreMachinesMk1(player) {

    if (!player.persistentData.getBoolean(MACHINES_MK1_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "machines_mk1")) {
        return
    }

    AStages.addStageToPlayer(player, "machines_mk1")

    console.info(
        "[STAGE RECOVERY] RESTORED machines_mk1 TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §emachines_mk1 §fstage has been restored."
    )
}


function restoreRotationalPowerGenerationMk1(player) {

    if (!player.persistentData.getBoolean(ROTATIONAL_POWER_GENERATION_MK1_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "rotational_power_generation_mk1")) {
        return
    }

    AStages.addStageToPlayer(player, "rotational_power_generation_mk1")

    console.info(
        "[STAGE RECOVERY] RESTORED rotational_power_generation_mk1 TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §erotational_power_generation_mk1 §fstage has been restored."
    )
}


function restoreContraptionsMk1(player) {

    if (!player.persistentData.getBoolean(CONTRAPTIONS_MK1_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "contraptions_mk1")) {
        return
    }

    AStages.addStageToPlayer(player, "contraptions_mk1")

    console.info(
        "[STAGE RECOVERY] RESTORED contraptions_mk1 TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §econtraptions_mk1 §fstage has been restored."
    )
}


function restoreRotationalPowerTransportationMk1(player) {

    if (!player.persistentData.getBoolean(ROTATIONAL_POWER_TRANSPORTATION_MK1_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "rotational_power_transportation_mk1")) {
        return
    }

    AStages.addStageToPlayer(player, "rotational_power_transportation_mk1")

    console.info(
        "[STAGE RECOVERY] RESTORED rotational_power_transportation_mk1 TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §erotational_power_transportation_mk1 §fstage has been restored."
    )
}


function restoreLogisticsMk1(player) {

    if (!player.persistentData.getBoolean(LOGISTICS_MK1_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "logistics_mk1")) {
        return
    }

    AStages.addStageToPlayer(player, "logistics_mk1")

    console.info(
        "[STAGE RECOVERY] RESTORED logistics_mk1 TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §elogistics_mk1 §fstage has been restored."
    )
}


function restoreStage2(player) {

    if (!player.persistentData.getBoolean(STAGE2_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "stage2")) {
        return
    }

    AStages.addStageToPlayer(player, "stage2")

    console.info(
        "[STAGE RECOVERY] RESTORED stage2 TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §estage2 §fstage has been restored."
    )
}


function restoreMachinesMk2(player) {

    if (!player.persistentData.getBoolean(MACHINES_MK2_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "machines_mk2")) {
        return
    }

    AStages.addStageToPlayer(player, "machines_mk2")

    console.info(
        "[STAGE RECOVERY] RESTORED machines_mk2 TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §emachines_mk2 §fstage has been restored."
    )
}


function restoreSuperHeating(player) {

    if (!player.persistentData.getBoolean(SUPER_HEATING_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "super_heating")) {
        return
    }

    AStages.addStageToPlayer(player, "super_heating")

    console.info(
        "[STAGE RECOVERY] RESTORED super_heating TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §esuper_heating §fstage has been restored."
    )
}


function restoreBlueprintsMk1(player) {

    if (!player.persistentData.getBoolean(BLUEPRINTS_MK1_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "blueprints_mk1")) {
        return
    }

    AStages.addStageToPlayer(player, "blueprints_mk1")

    console.info(
        "[STAGE RECOVERY] RESTORED blueprints_mk1 TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §eblueprints_mk1 §fstage has been restored."
    )
}


function restoreFluidsMk1(player) {

    if (!player.persistentData.getBoolean(FLUIDS_MK1_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "fluids_mk1")) {
        return
    }

    AStages.addStageToPlayer(player, "fluids_mk1")

    console.info(
        "[STAGE RECOVERY] RESTORED fluids_mk1 TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §efluids_mk1 §fstage has been restored."
    )
}


function restoreAdvancedRedstoneMk1(player) {

    if (!player.persistentData.getBoolean(ADVANCED_REDSTONE_MK1_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "advanced_redstone_mk1")) {
        return
    }

    AStages.addStageToPlayer(player, "advanced_redstone_mk1")

    console.info(
        "[STAGE RECOVERY] RESTORED advanced_redstone_mk1 TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §eadvanced_redstone_mk1 §fstage has been restored."
    )
}


function restorePostProduction(player) {

    if (!player.persistentData.getBoolean(POST_PRODUCTION_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "post_production")) {
        return
    }

    AStages.addStageToPlayer(player, "post_production")

    console.info(
        "[STAGE RECOVERY] RESTORED post_production TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §epost_production §fstage has been restored."
    )
}


function restoreStage3(player) {

    if (!player.persistentData.getBoolean(STAGE3_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "stage3")) {
        return
    }

    AStages.addStageToPlayer(player, "stage3")

    console.info(
        "[STAGE RECOVERY] RESTORED stage3 TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §estage3 §fstage has been restored."
    )
}


function restoreBrassProduction(player) {

    if (!player.persistentData.getBoolean(BRASS_PRODUCTION_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "brass_production")) {
        return
    }

    AStages.addStageToPlayer(player, "brass_production")

    console.info(
        "[STAGE RECOVERY] RESTORED brass_production TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §ebrass_production §fstage has been restored."
    )
}


function restoreAdvancedRedstoneMk2(player) {

    if (!player.persistentData.getBoolean(ADVANCED_REDSTONE_MK2_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "advanced_redstone_mk2")) {
        return
    }

    AStages.addStageToPlayer(player, "advanced_redstone_mk2")

    console.info(
        "[STAGE RECOVERY] RESTORED advanced_redstone_mk2 TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §eadvanced_redstone_mk2 §fstage has been restored."
    )
}


function restoreBetterItemManagment(player) {

    if (!player.persistentData.getBoolean(BETTER_ITEM_MANAGMENT_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "better_item_managment")) {
        return
    }

    AStages.addStageToPlayer(player, "better_item_managment")

    console.info(
        "[STAGE RECOVERY] RESTORED better_item_managment TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §ebetter_item_managment §fstage has been restored."
    )
}


function restoreAdvancedFluids(player) {

    if (!player.persistentData.getBoolean(ADVANCED_FLUIDS_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "advanced_fluids")) {
        return
    }

    AStages.addStageToPlayer(player, "advanced_fluids")

    console.info(
        "[STAGE RECOVERY] RESTORED advanced_fluids TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §eadvanced_fluids §fstage has been restored."
    )
}


function restoreLogisticsMk3(player) {

    if (!player.persistentData.getBoolean(LOGISTICS_MK3_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "logistics_mk3")) {
        return
    }

    AStages.addStageToPlayer(player, "logistics_mk3")

    console.info(
        "[STAGE RECOVERY] RESTORED logistics_mk3 TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §elogistics_mk3 §fstage has been restored."
    )
}


function restoreMovingContraptionsMk2(player) {

    if (!player.persistentData.getBoolean(MOVING_CONTRAPTIONS_MK2_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "moving_contraptions_mk2")) {
        return
    }

    AStages.addStageToPlayer(player, "moving_contraptions_mk2")

    console.info(
        "[STAGE RECOVERY] RESTORED moving_contraptions_mk2 TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §emoving_contraptions_mk2 §fstage has been restored."
    )
}


function restoreStage4(player) {

    if (!player.persistentData.getBoolean(STAGE4_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "stage4")) {
        return
    }

    AStages.addStageToPlayer(player, "stage4")

    console.info(
        "[STAGE RECOVERY] RESTORED stage4 TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §estage4 §fstage has been restored."
    )
}


function restoreSteamPowerGeneration(player) {

    if (!player.persistentData.getBoolean(STEAM_POWER_GENERATION_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "steam_power_generation")) {
        return
    }

    AStages.addStageToPlayer(player, "steam_power_generation")

    console.info(
        "[STAGE RECOVERY] RESTORED steam_power_generation TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §esteam_power_generation §fstage has been restored."
    )
}


function restoreMachinesMk4(player) {

    if (!player.persistentData.getBoolean(MACHINES_MK4_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "machines_mk4")) {
        return
    }

    AStages.addStageToPlayer(player, "machines_mk4")

    console.info(
        "[STAGE RECOVERY] RESTORED machines_mk4 TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §emachines_mk4 §fstage has been restored."
    )
}


function restoreTrains(player) {

    if (!player.persistentData.getBoolean(TRAINS_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "trains")) {
        return
    }

    AStages.addStageToPlayer(player, "trains")

    console.info(
        "[STAGE RECOVERY] RESTORED trains TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §etrains §fstage has been restored."
    )
}


function restoreAdvancedMachining(player) {

    if (!player.persistentData.getBoolean(ADVANCED_MACHINING_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "advanced_machining")) {
        return
    }

    AStages.addStageToPlayer(player, "advanced_machining")

    console.info(
        "[STAGE RECOVERY] RESTORED advanced_machining TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §eadvanced_machining §fstage has been restored."
    )
}


function restoreBetterEquipment(player) {

    if (!player.persistentData.getBoolean(BETTER_EQUIPMENT_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "better_equipment")) {
        return
    }

    AStages.addStageToPlayer(player, "better_equipment")

    console.info(
        "[STAGE RECOVERY] RESTORED better_equipment TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §ebetter_equipment §fstage has been restored."
    )
}


function restoreVehicleComponents(player) {

    if (!player.persistentData.getBoolean(VEHICLE_COMPONENTS_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "vehicle_components")) {
        return
    }

    AStages.addStageToPlayer(player, "vehicle_components")

    console.info(
        "[STAGE RECOVERY] RESTORED vehicle_components TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §evehicle_components §fstage has been restored."
    )
}


function restoreEconomy(player) {

    if (!player.persistentData.getBoolean(ECONOMY_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "economy")) {
        return
    }

    AStages.addStageToPlayer(player, "economy")

    console.info(
        "[STAGE RECOVERY] RESTORED economy TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §eeconomy §fstage has been restored."
    )
}


function restoreStage5(player) {

    if (!player.persistentData.getBoolean(STAGE5_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "stage5")) {
        return
    }

    AStages.addStageToPlayer(player, "stage5")

    console.info(
        "[STAGE RECOVERY] RESTORED stage5 TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §estage5 §fstage has been restored."
    )
}


function restoreDieselPowerGeneration(player) {

    if (!player.persistentData.getBoolean(DIESEL_POWER_GENERATION_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "diesel_power_generation")) {
        return
    }

    AStages.addStageToPlayer(player, "diesel_power_generation")

    console.info(
        "[STAGE RECOVERY] RESTORED diesel_power_generation TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §ediesel_power_generation §fstage has been restored."
    )
}


function restoreOil(player) {

    if (!player.persistentData.getBoolean(OIL_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "oil")) {
        return
    }

    AStages.addStageToPlayer(player, "oil")

    console.info(
        "[STAGE RECOVERY] RESTORED oil TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §eoil §fstage has been restored."
    )
}


function restoreAdvancedFarming(player) {

    if (!player.persistentData.getBoolean(ADVANCED_FARMING_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "advanced_farming")) {
        return
    }

    AStages.addStageToPlayer(player, "advanced_farming")

    console.info(
        "[STAGE RECOVERY] RESTORED advanced_farming TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §eadvanced_farming §fstage has been restored."
    )
}


function restoreElectricity(player) {

    if (!player.persistentData.getBoolean(ELECTRICITY_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "electricity")) {
        return
    }

    AStages.addStageToPlayer(player, "electricity")

    console.info(
        "[STAGE RECOVERY] RESTORED electricity TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §eelectricity §fstage has been restored."
    )
}


function restoreHypertubes(player) {

    if (!player.persistentData.getBoolean(HYPERTUBES_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "hypertubes")) {
        return
    }

    AStages.addStageToPlayer(player, "hypertubes")

    console.info(
        "[STAGE RECOVERY] RESTORED hypertubes TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §ehypertubes §fstage has been restored."
    )
}


function restoreEnchantmentIndustry(player) {

    if (!player.persistentData.getBoolean(ENCHANTMENT_INDUSTRY_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "enchantment_industry")) {
        return
    }

    AStages.addStageToPlayer(player, "enchantment_industry")

    console.info(
        "[STAGE RECOVERY] RESTORED enchantment_industry TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §eenchantment_industry §fstage has been restored."
    )
}


function restoreStage6(player) {

    if (!player.persistentData.getBoolean(STAGE6_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "stage6")) {
        return
    }

    AStages.addStageToPlayer(player, "stage6")

    console.info(
        "[STAGE RECOVERY] RESTORED stage6 TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §estage6 §fstage has been restored."
    )
}


function restoreItemSink(player) {

    if (!player.persistentData.getBoolean(ITEM_SINK_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "item_sink")) {
        return
    }

    AStages.addStageToPlayer(player, "item_sink")

    console.info(
        "[STAGE RECOVERY] RESTORED item_sink TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §eitem_sink §fstage has been restored."
    )
}


function restorePatternSchematics(player) {

    if (!player.persistentData.getBoolean(PATTERN_SCHEMATICS_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "pattern_schematics")) {
        return
    }

    AStages.addStageToPlayer(player, "pattern_schematics")

    console.info(
        "[STAGE RECOVERY] RESTORED pattern_schematics TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §epattern_schematics §fstage has been restored."
    )
}


function restoreJetpackMk1(player) {

    if (!player.persistentData.getBoolean(JETPACK_MK1_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "jetpack_mk1")) {
        return
    }

    AStages.addStageToPlayer(player, "jetpack_mk1")

    console.info(
        "[STAGE RECOVERY] RESTORED jetpack_mk1 TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §ejetpack_mk1 §fstage has been restored."
    )
}


function restoreChunkLoading(player) {

    if (!player.persistentData.getBoolean(CHUNK_LOADING_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "chunk_loading")) {
        return
    }

    AStages.addStageToPlayer(player, "chunk_loading")

    console.info(
        "[STAGE RECOVERY] RESTORED chunk_loading TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §echunk_loading §fstage has been restored."
    )
}


function restoreCannons(player) {

    if (!player.persistentData.getBoolean(CANNONS_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "cannons")) {
        return
    }

    AStages.addStageToPlayer(player, "cannons")

    console.info(
        "[STAGE RECOVERY] RESTORED cannons TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §ecannons §fstage has been restored."
    )
}


function restoreStage7(player) {

    if (!player.persistentData.getBoolean(STAGE7_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "stage7")) {
        return
    }

    AStages.addStageToPlayer(player, "stage7")

    console.info(
        "[STAGE RECOVERY] RESTORED stage7 TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §estage7 §fstage has been restored."
    )
}


function restoreAutomatedTrading(player) {

    if (!player.persistentData.getBoolean(AUTOMATED_TRADING_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "automated_trading")) {
        return
    }

    AStages.addStageToPlayer(player, "automated_trading")

    console.info(
        "[STAGE RECOVERY] RESTORED automated_trading TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §eautomated_trading §fstage has been restored."
    )
}


function restoreRadarComponents(player) {

    if (!player.persistentData.getBoolean(RADAR_COMPONENTS_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "radar_components")) {
        return
    }

    AStages.addStageToPlayer(player, "radar_components")

    console.info(
        "[STAGE RECOVERY] RESTORED radar_components TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §eradar_components §fstage has been restored."
    )
}


function restoreOpticalFabrication(player) {

    if (!player.persistentData.getBoolean(OPTICAL_FABRICATION_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "optical_fabrication")) {
        return
    }

    AStages.addStageToPlayer(player, "optical_fabrication")

    console.info(
        "[STAGE RECOVERY] RESTORED optical_fabrication TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §eoptical_fabrication §fstage has been restored."
    )
}


function restoreEngraving(player) {

    if (!player.persistentData.getBoolean(ENGRAVING_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "engraving")) {
        return
    }

    AStages.addStageToPlayer(player, "engraving")

    console.info(
        "[STAGE RECOVERY] RESTORED engraving TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §eengraving §fstage has been restored."
    )
}


function restoreAirshipComponents(player) {

    if (!player.persistentData.getBoolean(AIRSHIP_COMPONENTS_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "airship_components")) {
        return
    }

    AStages.addStageToPlayer(player, "airship_components")

    console.info(
        "[STAGE RECOVERY] RESTORED airship_components TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §eairship_components §fstage has been restored."
    )
}


function restoreAstrophotographyGear(player) {

    if (!player.persistentData.getBoolean(ASTROPHOTOGRAPHY_GEAR_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "astrophotography_gear")) {
        return
    }

    AStages.addStageToPlayer(player, "astrophotography_gear")

    console.info(
        "[STAGE RECOVERY] RESTORED astrophotography_gear TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §eastrophotography_gear §fstage has been restored."
    )
}


function restoreMobilePackages(player) {

    if (!player.persistentData.getBoolean(MOBILE_PACKAGES_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "mobile_packages")) {
        return
    }

    AStages.addStageToPlayer(player, "mobile_packages")

    console.info(
        "[STAGE RECOVERY] RESTORED mobile_packages TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §emobile_packages §fstage has been restored."
    )
}


function restoreStage8(player) {

    if (!player.persistentData.getBoolean(STAGE8_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "stage8")) {
        return
    }

    AStages.addStageToPlayer(player, "stage8")

    console.info(
        "[STAGE RECOVERY] RESTORED stage8 TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §estage8 §fstage has been restored."
    )
}


function restoreJetpackMk2(player) {

    if (!player.persistentData.getBoolean(JETPACK_MK2_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "jetpack_mk2")) {
        return
    }

    AStages.addStageToPlayer(player, "jetpack_mk2")

    console.info(
        "[STAGE RECOVERY] RESTORED jetpack_mk2 TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §ejetpack_mk2 §fstage has been restored."
    )
}


function restoreSpacecraftComponents(player) {

    if (!player.persistentData.getBoolean(SPACECRAFT_COMPONENTS_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "spacecraft_components")) {
        return
    }

    AStages.addStageToPlayer(player, "spacecraft_components")

    console.info(
        "[STAGE RECOVERY] RESTORED spacecraft_components TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §espacecraft_components §fstage has been restored."
    )
}


function restoreSpaceGear(player) {

    if (!player.persistentData.getBoolean(SPACE_GEAR_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "space_gear")) {
        return
    }

    AStages.addStageToPlayer(player, "space_gear")

    console.info(
        "[STAGE RECOVERY] RESTORED space_gear TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §espace_gear §fstage has been restored."
    )
}


function restoreAtmosphericMachinery(player) {

    if (!player.persistentData.getBoolean(ATMOSPHERIC_MACHINERY_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "atmospheric_machinery")) {
        return
    }

    AStages.addStageToPlayer(player, "atmospheric_machinery")

    console.info(
        "[STAGE RECOVERY] RESTORED atmospheric_machinery TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §eatmospheric_machinery §fstage has been restored."
    )
}


function restoreGyroscopicComponents(player) {

    if (!player.persistentData.getBoolean(GYROSCOPIC_COMPONENTS_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "gyroscopic_components")) {
        return
    }

    AStages.addStageToPlayer(player, "gyroscopic_components")

    console.info(
        "[STAGE RECOVERY] RESTORED gyroscopic_components TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §egyroscopic_components §fstage has been restored."
    )
}


function restoreRocketPropulsion(player) {

    if (!player.persistentData.getBoolean(ROCKET_PROPULSION_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "rocket_propulsion")) {
        return
    }

    AStages.addStageToPlayer(player, "rocket_propulsion")

    console.info(
        "[STAGE RECOVERY] RESTORED rocket_propulsion TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §erocket_propulsion §fstage has been restored."
    )
}


function restoreStage9(player) {

    if (!player.persistentData.getBoolean(STAGE9_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "stage9")) {
        return
    }

    AStages.addStageToPlayer(player, "stage9")

    console.info(
        "[STAGE RECOVERY] RESTORED stage9 TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §estage9 §fstage has been restored."
    )
}


function restoreNuclearReactorComponents(player) {

    if (!player.persistentData.getBoolean(NUCLEAR_REACTOR_COMPONENTS_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "nuclear_reactor_components")) {
        return
    }

    AStages.addStageToPlayer(player, "nuclear_reactor_components")

    console.info(
        "[STAGE RECOVERY] RESTORED nuclear_reactor_components TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §enuclear_reactor_components §fstage has been restored."
    )
}


function restoreAdvancedPowerGeneration(player) {

    if (!player.persistentData.getBoolean(ADVANCED_POWER_GENERATION_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "advanced_power_generation")) {
        return
    }

    AStages.addStageToPlayer(player, "advanced_power_generation")

    console.info(
        "[STAGE RECOVERY] RESTORED advanced_power_generation TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §eadvanced_power_generation §fstage has been restored."
    )
}


function restoreLunarSpacecraftComponents(player) {

    if (!player.persistentData.getBoolean(LUNAR_SPACECRAFT_COMPONENTS_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "lunar_spacecraft_components")) {
        return
    }

    AStages.addStageToPlayer(player, "lunar_spacecraft_components")

    console.info(
        "[STAGE RECOVERY] RESTORED lunar_spacecraft_components TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §elunar_spacecraft_components §fstage has been restored."
    )
}


function restoreLunarAtmosphericMachinery(player) {

    if (!player.persistentData.getBoolean(LUNAR_ATMOSPHERIC_MACHINERY_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "lunar_atmospheric_machinery")) {
        return
    }

    AStages.addStageToPlayer(player, "lunar_atmospheric_machinery")

    console.info(
        "[STAGE RECOVERY] RESTORED lunar_atmospheric_machinery TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §elunar_atmospheric_machinery §fstage has been restored."
    )
}


function restoreMartianSpaceGear(player) {

    if (!player.persistentData.getBoolean(MARTIAN_SPACE_GEAR_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "martian_space_gear")) {
        return
    }

    AStages.addStageToPlayer(player, "martian_space_gear")

    console.info(
        "[STAGE RECOVERY] RESTORED martian_space_gear TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §emartian_space_gear §fstage has been restored."
    )
}


function restoreMechanicalCompanion(player) {

    if (!player.persistentData.getBoolean(MECHANICAL_COMPANION_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "mechanical_companion")) {
        return
    }

    AStages.addStageToPlayer(player, "mechanical_companion")

    console.info(
        "[STAGE RECOVERY] RESTORED mechanical_companion TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §emechanical_companion §fstage has been restored."
    )
}


function restoreStage10(player) {

    if (!player.persistentData.getBoolean(STAGE10_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "stage10")) {
        return
    }

    AStages.addStageToPlayer(player, "stage10")

    console.info(
        "[STAGE RECOVERY] RESTORED stage10 TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §estage10 §fstage has been restored."
    )
}


function restoreCreateQol(player) {

    if (!player.persistentData.getBoolean(CREATEQOL_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "createqol")) {
        return
    }

    AStages.addStageToPlayer(player, "createqol")

    console.info(
        "[STAGE RECOVERY] RESTORED createqol TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §ecreateqol §fstage has been restored."
    )
}


function restoreTeleportation(player) {

    if (!player.persistentData.getBoolean(TELEPORTATION_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "teleportation")) {
        return
    }

    AStages.addStageToPlayer(player, "teleportation")

    console.info(
        "[STAGE RECOVERY] RESTORED teleportation TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §eteleportation §fstage has been restored."
    )
}


function restorePocketDimension(player) {

    if (!player.persistentData.getBoolean(POCKET_DIMENSION_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "pocket_dimension")) {
        return
    }

    AStages.addStageToPlayer(player, "pocket_dimension")

    console.info(
        "[STAGE RECOVERY] RESTORED pocket_dimension TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §epocket_dimension §fstage has been restored."
    )
}


function restoreAdvancedTeleportation(player) {

    if (!player.persistentData.getBoolean(ADVANCED_TELEPORTATION_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "advanced_teleportation")) {
        return
    }

    AStages.addStageToPlayer(player, "advanced_teleportation")

    console.info(
        "[STAGE RECOVERY] RESTORED advanced_teleportation TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §eadvanced_teleportation §fstage has been restored."
    )
}


function restoreAdvancedPropulsion(player) {

    if (!player.persistentData.getBoolean(ADVANCED_PROPULSION_DATA)) {
        return
    }

    if (AStages.playerHasStage(player, "advanced_propulsion")) {
        return
    }

    AStages.addStageToPlayer(player, "advanced_propulsion")

    console.info(
        "[STAGE RECOVERY] RESTORED advanced_propulsion TO " +
        player.username
    )

    player.tell(
        "§6§lProgression Recovered!§r\n" +
        "§fYour §eadvanced_propulsion §fstage has been restored."
    )
}

ServerEvents.commandRegistry(event => {

    event.register(
        event.commands.literal("stagebackup")

.then(
    event.commands.literal("copycats")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                COPYCATS_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked copycats"
            )

            restoreCopycats(player)

            return 1
        })
)

.then(
    event.commands.literal("stage1")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                STAGE1_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked stage1"
            )

            restoreStage1(player)

            return 1
        })
)

.then(
    event.commands.literal("diving_equipment_mk1")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                DIVING_EQUIPMENT_MK1_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked diving_equipment_mk1"
            )

            restoreDivingEquipmentMk1(player)

            return 1
        })
)

.then(
    event.commands.literal("machines_mk1")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                MACHINES_MK1_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked machines_mk1"
            )

            restoreMachinesMk1(player)

            return 1
        })
)

.then(
    event.commands.literal("rotational_power_generation_mk1")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                ROTATIONAL_POWER_GENERATION_MK1_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked rotational_power_generation_mk1"
            )

            restoreRotationalPowerGenerationMk1(player)

            return 1
        })
)

.then(
    event.commands.literal("contraptions_mk1")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                CONTRAPTIONS_MK1_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked contraptions_mk1"
            )

            restoreContraptionsMk1(player)

            return 1
        })
)

.then(
    event.commands.literal("rotational_power_transportation_mk1")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                ROTATIONAL_POWER_TRANSPORTATION_MK1_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked rotational_power_transportation_mk1"
            )

            restoreRotationalPowerTransportationMk1(player)

            return 1
        })
)

.then(
    event.commands.literal("logistics_mk1")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                LOGISTICS_MK1_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked logistics_mk1"
            )

            restoreLogisticsMk1(player)

            return 1
        })
)

.then(
    event.commands.literal("stage2")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                STAGE2_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked stage2"
            )

            restoreStage2(player)

            return 1
        })
)

.then(
    event.commands.literal("machines_mk2")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                MACHINES_MK2_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked machines_mk2"
            )

            restoreMachinesMk2(player)

            return 1
        })
)

.then(
    event.commands.literal("super_heating")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                SUPER_HEATING_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked super_heating"
            )

            restoreSuperHeating(player)

            return 1
        })
)

.then(
    event.commands.literal("blueprints_mk1")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                BLUEPRINTS_MK1_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked blueprints_mk1"
            )

            restoreBlueprintsMk1(player)

            return 1
        })
)

.then(
    event.commands.literal("fluids_mk1")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                FLUIDS_MK1_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked fluids_mk1"
            )

            restoreFluidsMk1(player)

            return 1
        })
)

.then(
    event.commands.literal("advanced_redstone_mk1")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                ADVANCED_REDSTONE_MK1_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked advanced_redstone_mk1"
            )

            restoreAdvancedRedstoneMk1(player)

            return 1
        })
)

.then(
    event.commands.literal("post_production")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                POST_PRODUCTION_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked post_production"
            )

            restorePostProduction(player)

            return 1
        })
)

.then(
    event.commands.literal("stage3")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                STAGE3_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked stage3"
            )

            restoreStage3(player)

            return 1
        })
)

.then(
    event.commands.literal("brass_production")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                BRASS_PRODUCTION_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked brass_production"
            )

            restoreBrassProduction(player)

            return 1
        })
)

.then(
    event.commands.literal("advanced_redstone_mk2")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                ADVANCED_REDSTONE_MK2_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked advanced_redstone_mk2"
            )

            restoreAdvancedRedstoneMk2(player)

            return 1
        })
)

.then(
    event.commands.literal("better_item_managment")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                BETTER_ITEM_MANAGMENT_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked better_item_managment"
            )

            restoreBetterItemManagment(player)

            return 1
        })
)

.then(
    event.commands.literal("advanced_fluids")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                ADVANCED_FLUIDS_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked advanced_fluids"
            )

            restoreAdvancedFluids(player)

            return 1
        })
)

.then(
    event.commands.literal("logistics_mk3")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                LOGISTICS_MK3_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked logistics_mk3"
            )

            restoreLogisticsMk3(player)

            return 1
        })
)

.then(
    event.commands.literal("moving_contraptions_mk2")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                MOVING_CONTRAPTIONS_MK2_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked moving_contraptions_mk2"
            )

            restoreMovingContraptionsMk2(player)

            return 1
        })
)

.then(
    event.commands.literal("stage4")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                STAGE4_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked stage4"
            )

            restoreStage4(player)

            return 1
        })
)

.then(
    event.commands.literal("steam_power_generation")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                STEAM_POWER_GENERATION_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked steam_power_generation"
            )

            restoreSteamPowerGeneration(player)

            return 1
        })
)

.then(
    event.commands.literal("machines_mk4")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                MACHINES_MK4_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked machines_mk4"
            )

            restoreMachinesMk4(player)

            return 1
        })
)

.then(
    event.commands.literal("trains")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                TRAINS_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked trains"
            )

            restoreTrains(player)

            return 1
        })
)

.then(
    event.commands.literal("advanced_machining")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                ADVANCED_MACHINING_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked advanced_machining"
            )

            restoreAdvancedMachining(player)

            return 1
        })
)

.then(
    event.commands.literal("better_equipment")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                BETTER_EQUIPMENT_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked better_equipment"
            )

            restoreBetterEquipment(player)

            return 1
        })
)

.then(
    event.commands.literal("vehicle_components")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                VEHICLE_COMPONENTS_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked vehicle_components"
            )

            restoreVehicleComponents(player)

            return 1
        })
)

.then(
    event.commands.literal("economy")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                ECONOMY_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked economy"
            )

            restoreEconomy(player)

            return 1
        })
)

.then(
    event.commands.literal("stage5")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                STAGE5_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked stage5"
            )

            restoreStage5(player)

            return 1
        })
)

.then(
    event.commands.literal("diesel_power_generation")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                DIESEL_POWER_GENERATION_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked diesel_power_generation"
            )

            restoreDieselPowerGeneration(player)

            return 1
        })
)

.then(
    event.commands.literal("oil")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                OIL_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked oil"
            )

            restoreOil(player)

            return 1
        })
)

.then(
    event.commands.literal("advanced_farming")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                ADVANCED_FARMING_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked advanced_farming"
            )

            restoreAdvancedFarming(player)

            return 1
        })
)

.then(
    event.commands.literal("electricity")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                ELECTRICITY_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked electricity"
            )

            restoreElectricity(player)

            return 1
        })
)

.then(
    event.commands.literal("hypertubes")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                HYPERTUBES_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked hypertubes"
            )

            restoreHypertubes(player)

            return 1
        })
)

.then(
    event.commands.literal("enchantment_industry")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                ENCHANTMENT_INDUSTRY_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked enchantment_industry"
            )

            restoreEnchantmentIndustry(player)

            return 1
        })
)

.then(
    event.commands.literal("stage6")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                STAGE6_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked stage6"
            )

            restoreStage6(player)

            return 1
        })
)

.then(
    event.commands.literal("item_sink")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                ITEM_SINK_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked item_sink"
            )

            restoreItemSink(player)

            return 1
        })
)

.then(
    event.commands.literal("pattern_schematics")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                PATTERN_SCHEMATICS_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked pattern_schematics"
            )

            restorePatternSchematics(player)

            return 1
        })
)

.then(
    event.commands.literal("jetpack_mk1")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                JETPACK_MK1_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked jetpack_mk1"
            )

            restoreJetpackMk1(player)

            return 1
        })
)

.then(
    event.commands.literal("chunk_loading")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                CHUNK_LOADING_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked chunk_loading"
            )

            restoreChunkLoading(player)

            return 1
        })
)

.then(
    event.commands.literal("cannons")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                CANNONS_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked cannons"
            )

            restoreCannons(player)

            return 1
        })
)

.then(
    event.commands.literal("stage7")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                STAGE7_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked stage7"
            )

            restoreStage7(player)

            return 1
        })
)

.then(
    event.commands.literal("automated_trading")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                AUTOMATED_TRADING_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked automated_trading"
            )

            restoreAutomatedTrading(player)

            return 1
        })
)

.then(
    event.commands.literal("radar_components")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                RADAR_COMPONENTS_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked radar_components"
            )

            restoreRadarComponents(player)

            return 1
        })
)

.then(
    event.commands.literal("optical_fabrication")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                OPTICAL_FABRICATION_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked optical_fabrication"
            )

            restoreOpticalFabrication(player)

            return 1
        })
)

.then(
    event.commands.literal("engraving")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                ENGRAVING_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked engraving"
            )

            restoreEngraving(player)

            return 1
        })
)

.then(
    event.commands.literal("airship_components")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                AIRSHIP_COMPONENTS_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked airship_components"
            )

            restoreAirshipComponents(player)

            return 1
        })
)

.then(
    event.commands.literal("astrophotography_gear")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                ASTROPHOTOGRAPHY_GEAR_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked astrophotography_gear"
            )

            restoreAstrophotographyGear(player)

            return 1
        })
)

.then(
    event.commands.literal("mobile_packages")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                MOBILE_PACKAGES_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked mobile_packages"
            )

            restoreMobilePackages(player)

            return 1
        })
)

.then(
    event.commands.literal("stage8")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                STAGE8_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked stage8"
            )

            restoreStage8(player)

            return 1
        })
)

.then(
    event.commands.literal("jetpack_mk2")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                JETPACK_MK2_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked jetpack_mk2"
            )

            restoreJetpackMk2(player)

            return 1
        })
)

.then(
    event.commands.literal("spacecraft_components")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                SPACECRAFT_COMPONENTS_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked spacecraft_components"
            )

            restoreSpacecraftComponents(player)

            return 1
        })
)

.then(
    event.commands.literal("space_gear")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                SPACE_GEAR_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked space_gear"
            )

            restoreSpaceGear(player)

            return 1
        })
)

.then(
    event.commands.literal("atmospheric_machinery")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                ATMOSPHERIC_MACHINERY_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked atmospheric_machinery"
            )

            restoreAtmosphericMachinery(player)

            return 1
        })
)

.then(
    event.commands.literal("gyroscopic_components")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                GYROSCOPIC_COMPONENTS_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked gyroscopic_components"
            )

            restoreGyroscopicComponents(player)

            return 1
        })
)

.then(
    event.commands.literal("rocket_propulsion")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                ROCKET_PROPULSION_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked rocket_propulsion"
            )

            restoreRocketPropulsion(player)

            return 1
        })
)

.then(
    event.commands.literal("stage9")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                STAGE9_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked stage9"
            )

            restoreStage9(player)

            return 1
        })
)

.then(
    event.commands.literal("nuclear_reactor_components")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                NUCLEAR_REACTOR_COMPONENTS_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked nuclear_reactor_components"
            )

            restoreNuclearReactorComponents(player)

            return 1
        })
)

.then(
    event.commands.literal("advanced_power_generation")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                ADVANCED_POWER_GENERATION_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked advanced_power_generation"
            )

            restoreAdvancedPowerGeneration(player)

            return 1
        })
)

.then(
    event.commands.literal("lunar_spacecraft_components")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                LUNAR_SPACECRAFT_COMPONENTS_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked lunar_spacecraft_components"
            )

            restoreLunarSpacecraftComponents(player)

            return 1
        })
)

.then(
    event.commands.literal("lunar_atmospheric_machinery")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                LUNAR_ATMOSPHERIC_MACHINERY_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked lunar_atmospheric_machinery"
            )

            restoreLunarAtmosphericMachinery(player)

            return 1
        })
)

.then(
    event.commands.literal("martian_space_gear")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                MARTIAN_SPACE_GEAR_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked martian_space_gear"
            )

            restoreMartianSpaceGear(player)

            return 1
        })
)

.then(
    event.commands.literal("mechanical_companion")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                MECHANICAL_COMPANION_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked mechanical_companion"
            )

            restoreMechanicalCompanion(player)

            return 1
        })
)

.then(
    event.commands.literal("stage10")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                STAGE10_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked stage10"
            )

            restoreStage10(player)

            return 1
        })
)

.then(
    event.commands.literal("createqol")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                CREATEQOL_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked createqol"
            )

            restoreCreateqol(player)

            return 1
        })
)

.then(
    event.commands.literal("teleportation")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                TELEPORTATION_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked teleportation"
            )

            restoreTeleportation(player)

            return 1
        })
)

.then(
    event.commands.literal("pocket_dimension")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                POCKET_DIMENSION_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked pocket_dimension"
            )

            restorePocketDimension(player)

            return 1
        })
)

.then(
    event.commands.literal("advanced_teleportation")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                ADVANCED_TELEPORTATION_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked advanced_teleportation"
            )

            restoreAdvancedTeleportation(player)

            return 1
        })
)

.then(
    event.commands.literal("advanced_propulsion")
        .executes(ctx => {

            const player = ctx.source.player

            if (!player) {
                return 0
            }

            player.persistentData.putBoolean(
                ADVANCED_PROPULSION_DATA,
                true
            )

            console.info(
                "[STAGE RECOVERY] " +
                player.username +
                " permanently unlocked advanced_propulsion"
            )

            restoreAdvancedPropulsion(player)

            return 1
        })
)
    )
})

PlayerEvents.loggedIn(event => {

    const player = event.player

    // EXACT SAME METHOD AS THE WORKING SCRIPT
    event.server.scheduleInTicks(20, () => {

        restoreCopycats(player)
        restoreStage1(player)
        restoreDivingEquipmentMk1(player)
        restoreMachinesMk1(player)
        restoreRotationalPowerGenerationMk1(player)
        restoreContraptionsMk1(player)
        restoreRotationalPowerTransportationMk1(player)
        restoreLogisticsMk1(player)

        restoreStage2(player)
        restoreMachinesMk2(player)
        restoreSuperHeating(player)
        restoreBlueprintsMk1(player)
        restoreFluidsMk1(player)
        restoreAdvancedRedstoneMk1(player)
        restorePostProduction(player)

        restoreStage3(player)
        restoreBrassProduction(player)
        restoreAdvancedRedstoneMk2(player)
        restoreBetterItemManagment(player)
        restoreAdvancedFluids(player)
        restoreLogisticsMk3(player)
        restoreMovingContraptionsMk2(player)

        restoreStage4(player)
        restoreSteamPowerGeneration(player)
        restoreMachinesMk4(player)
        restoreTrains(player)
        restoreAdvancedMachining(player)
        restoreBetterEquipment(player)
        restoreVehicleComponents(player)
        restoreEconomy(player)

        restoreStage5(player)
        restoreDieselPowerGeneration(player)
        restoreOil(player)
        restoreAdvancedFarming(player)
        restoreElectricity(player)
        restoreHypertubes(player)
        restoreEnchantmentIndustry(player)

        restoreStage6(player)
        restoreItemSink(player)
        restorePatternSchematics(player)
        restoreJetpackMk1(player)
        restoreChunkLoading(player)
        restoreCannons(player)

        restoreStage7(player)
        restoreAutomatedTrading(player)
        restoreRadarComponents(player)
        restoreOpticalFabrication(player)
        restoreEngraving(player)
        restoreAirshipComponents(player)
        restoreAstrophotographyGear(player)
        restoreMobilePackages(player)

        restoreStage8(player)
        restoreJetpackMk2(player)
        restoreSpacecraftComponents(player)
        restoreSpaceGear(player)
        restoreAtmosphericMachinery(player)
        restoreGyroscopicComponents(player)
        restoreRocketPropulsion(player)

        restoreStage9(player)
        restoreNuclearReactorComponents(player)
        restoreAdvancedPowerGeneration(player)
        restoreLunarSpacecraftComponents(player)
        restoreLunarAtmosphericMachinery(player)
        restoreMartianSpaceGear(player)
        restoreMechanicalCompanion(player)

        restoreStage10(player)
        restoreCreateQol(player)
        restoreTeleportation(player)
        restorePocketDimension(player)
        restoreAdvancedTeleportation(player)
        restoreAdvancedPropulsion(player)

    })
})