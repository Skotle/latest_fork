PlayerEvents.loggedIn(event => {
    const player = event.player
    
    // This checks if the player has never joined this world before
    if (!player.persistentData.contains("hasJoinedBefore")) {
        
        player.persistentData.putBoolean("hasJoinedBefore", true)
        
        player.tell([
            Component.literal("§o If you want to experience this pack without the milestones or item restrictions, run /unlockallstages (requires op)."),
        ])
    }
})