AStages.addRestrictionForTag("copycats", "copycats", "astages:copycats")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('copycats')
    .titleOnAdd(stage => Component.literal('§6Reserch Complete!'))
    .subTitleOnAdd(stage => Component.literal('§lCopycat Blocks'))
    .stay(120)

// ==================== Stage 1 ====================
AStages.addRestrictionForTag("stage1", "stage1", "astages:stage1")
    .globalShowName()
    .showInRecipeViewer()
    .hiddenName(stack => Component.literal("§cLOCKED - Complete Tutorial!"))
    .useMessage(stack => Component.literal("Must Complete the Tutorial! View your Cog-PDA!"))
    .pickupMessage(stack => Component.literal("Must Complete the Tutorial! View your Cog-PDA!"))
    .placeMessage(stack => Component.literal("Must Complete the Tutorial! View your Cog-PDA!"))
    .mineMessage(stack => Component.literal("Must Complete the Tutorial! View your Cog-PDA!"))
    .attackMessage(stack => Component.literal("Must Complete the Tutorial! View your Cog-PDA!"));

AStages.customizeStage('stage1')
    .titleOnAdd(stage => Component.literal('§6§aStage 1 Unlocked'))
    .subTitleOnAdd(stage => Component.literal('§lNew Milestones are now available'))
    .setFadeIn(20) 
    .setFadeOut(20) 
    .setStay(180) 

AStages.addRestrictionForTag("diving_equipment_mk1", "diving_equipment_mk1", "astages:diving_equipment_mk1")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('diving_equipment_mk1')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lCopper Diving Equipment'))
    .stay(120)

AStages.addRestrictionForTag("machines_mk1", "machines_mk1", "astages:machines_mk1")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('machines_mk1')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lBasic Machinery'))
    .setStay(120) 

AStages.addRestrictionForTag("contraptions_mk1", "contraptions_mk1", "astages:contraptions_mk1")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('contraptions_mk1')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lContraptions'))
    .setStay(120) 

AStages.addRestrictionForTag("rotational_power_generation_mk1", "rotational_power_generation_mk1", "astages:rotational_power_generation_mk1")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('rotational_power_generation_mk1')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lRotational Power Generation'))
    .setStay(120) 

AStages.addRestrictionForTag("rotational_power_transportation_mk1", "rotational_power_transportation_mk1", "astages:rotational_power_transportation_mk1")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('rotational_power_transportation_mk1')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lRotational Power Transportation'))
    .setStay(120) 

AStages.addRestrictionForTag("logistics_mk1", "logistics_mk1", "astages:logistics_mk1")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('logistics_mk1')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lLogistics'))
    .setStay(120) 

// ==================== Stage 2 ====================

AStages.customizeStage('stage2')
    .titleOnAdd(stage => Component.literal('§6§aStage 2 Unlocked'))
    .subTitleOnAdd(stage => Component.literal('§lNew Milestones are now available'))
    .setFadeIn(20) 
    .setFadeOut(20) 
    .setStay(180) 

AStages.addRestrictionForTag("machines_mk2", "machines_mk2", "astages:machines_mk2")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('machines_mk2')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lAdvanced Processing'))
    .setStay(120) 

AStages.addRestrictionForTag("super_heating", "super_heating", "astages:super_heating")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('super_heating')
    .setAddTitle('§6MILESTONE UNLOCKED') 
    .setAddSubTitle('§lSuper Heating') 
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lAdvanced Processing'))
    .setStay(120) 

AStages.addRestrictionForTag("blueprints_mk1", "blueprints_mk1", "astages:blueprints_mk1")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('blueprints_mk1')
    .setAddTitle('§6MILESTONE UNLOCKED') 
    .setAddSubTitle('§lSchematics') 
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lSchematics'))
    .setStay(120) 

AStages.addRestrictionForTag("fluids_mk1", "fluids_mk1", "astages:fluids_mk1")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('fluids_mk1')
    .setAddTitle('§6MILESTONE UNLOCKED') 
    .setAddSubTitle('§lBasic Fluids') 
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lFluids'))
    .setStay(120) 

AStages.addRestrictionForTag("advanced_redstone_mk1", "advanced_redstone_mk1", "astages:advanced_redstone_mk1")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('advanced_redstone_mk1')
    .setAddTitle('§6MILESTONE UNLOCKED') 
    .setAddSubTitle('§lAdvanced Redstone') 
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lAdvanced Redstone'))
    .setStay(120) 

AStages.addRestrictionForTag("post_production", "post_production", "astages:post_production")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('post_production')
    .setAddTitle('§6MILESTONE UNLOCKED') 
    .setAddSubTitle('§lPost Production') 
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lPost Production'))
    .setStay(120) 

// ==================== Stage 3 ====================

AStages.customizeStage('stage3')
    .titleOnAdd(stage => Component.literal('§6§aStage 3 Unlocked'))
    .subTitleOnAdd(stage => Component.literal('§lNew Milestones are now available'))
    .setFadeIn(20) 
    .setFadeOut(20) 
    .setStay(180) 

AStages.addRestrictionForTag("brass_production", "brass_production", "astages:brass_production")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('brass_production')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lAdvanced Crafting'))
    .setStay(120) 

AStages.addRestrictionForTag("advanced_redstone_mk2", "advanced_redstone_mk2", "astages:advanced_redstone_mk2")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('advanced_redstone_mk2')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lSmart Redstone'))
    .setStay(120) 

AStages.addRestrictionForTag("better_item_managment", "better_item_managment", "astages:better_item_managment")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('better_item_managment')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lBetter Item Managment'))
    .setStay(120) 

AStages.addRestrictionForTag("advanced_fluids", "advanced_fluids", "astages:advanced_fluids")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('advanced_fluids')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lBetter Fluids'))
    .setStay(120) 

AStages.addRestrictionForTag("logistics_mk3", "logistics_mk3", "astages:logistics_mk3")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('logistics_mk3')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lBetter Logistics'))
    .setStay(120) 

AStages.addRestrictionForTag("moving_contraptions_mk2", "moving_contraptions_mk2", "astages:moving_contraptions_mk2")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('moving_contraptions_mk2')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lBetter Contraptions'))
    .setStay(120) 

// ==================== Stage 4 ====================

AStages.customizeStage('stage4')
    .titleOnAdd(stage => Component.literal('§6§aStage 4 Unlocked'))
    .subTitleOnAdd(stage => Component.literal('§lNew Milestones are now available'))
    .setFadeIn(20) 
    .setFadeOut(20) 
    .setStay(180) 

AStages.addRestrictionForTag("steam_power_generation", "steam_power_generation", "astages:steam_power_generation")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('steam_power_generation')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lSteam Components'))
    .setStay(120) 

AStages.addRestrictionForTag("machines_mk4", "machines_mk4", "astages:machines_mk4")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('machines_mk4')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lSequenced Machinery'))
    .setStay(120) 

AStages.addRestrictionForTag("trains", "trains", "astages:trains")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('trains')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lTrains'))
    .setStay(120) 

AStages.addRestrictionForTag("advanced_machining", "advanced_machining", "astages:advanced_machining")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('advanced_machining')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lAdvanced Machining'))
    .setStay(120) 

AStages.addRestrictionForTag("better_equipment", "better_equipment", "astages:better_equipment")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('better_equipment')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lBetter Equipment'))
    .setStay(120) 

AStages.addRestrictionForTag("vehicle_components", "vehicle_components", "astages:vehicle_components")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('vehicle_components')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lVehicle Components'))
    .setStay(120) 

AStages.addRestrictionForTag("economy", "economy", "astages:economy")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('economy')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lEconomy'))
    .setStay(120) 

// ==================== Stage 5 ====================

AStages.customizeStage('stage5')
    .titleOnAdd(stage => Component.literal('§6§aStage 5 Unlocked'))
    .subTitleOnAdd(stage => Component.literal('§lNew Milestones are now available'))
    .setFadeIn(20) 
    .setFadeOut(20) 
    .setStay(180) 

AStages.addRestrictionForTag("diesel_power_generation", "diesel_power_generation", "astages:diesel_power_generation")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('diesel_power_generation')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lDiesel Power Generation'))
    .setStay(120) 

AStages.addRestrictionForTag("oil", "oil", "astages:oil")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('oil')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lOil Production'))
    .setStay(120) 

AStages.addRestrictionForTag("advanced_farming", "advanced_farming", "astages:advanced_farming")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('advanced_farming')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lAdvanced Farming'))
    .setStay(120) 

AStages.addRestrictionForTag("electricity", "electricity", "astages:electricity")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('electricity')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lElectricity'))
    .setStay(120) 

AStages.addRestrictionForTag("hypertubes", "hypertubes", "astages:hypertubes")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('hypertubes')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lHypertubes'))
    .setStay(120)

AStages.addRestrictionForTag("enchantment_industry", "enchantment_industry", "astages:enchantment_industry")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('enchantment_industry')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lEnchantment Industry'))
    .setStay(120)

// ==================== Stage 6 ====================

AStages.customizeStage('stage6')
    .titleOnAdd(stage => Component.literal('§6§aStage 6 Unlocked'))
    .subTitleOnAdd(stage => Component.literal('§lNew Milestones are now available'))
    .setFadeIn(20) 
    .setFadeOut(20) 
    .setStay(180) 

AStages.addRestrictionForTag("item_sink", "item_sink", "astages:item_sink")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('item_sink')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lItem Sink'))
    .setStay(120)

AStages.addRestrictionForTag("pattern_schematics", "pattern_schematics", "astages:pattern_schematics")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('pattern_schematics')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lPattern Schematics'))
    .setStay(120)

AStages.addRestrictionForTag("jetpack_mk1", "jetpack_mk1", "astages:jetpack_mk1")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('jetpack_mk1')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lJetpack'))
    .setStay(120)

AStages.addRestrictionForTag("chunk_loading", "chunk_loading", "astages:chunk_loading")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('chunk_loading')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lChunk Loading'))
    .setStay(120)

AStages.addRestrictionForTag("cannons", "cannons", "astages:cannons")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('cannons')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§Cannons'))
    .setStay(120)

// ==================== Stage 7 ====================

AStages.customizeStage('stage7')
    .titleOnAdd(stage => Component.literal('§6§aStage 7 Unlocked'))
    .subTitleOnAdd(stage => Component.literal('§lNew Milestones are now available'))
    .setFadeIn(20) 
    .setFadeOut(20) 
    .setStay(180)

AStages.addRestrictionForTag("automated_trading", "automated_trading", "astages:automated_trading")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('automated_trading')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lAutomated Trading'))
    .setStay(120)

AStages.addRestrictionForTag("radar_components", "radar_components", "astages:radar_components")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('radar_components')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lRadar Components'))
    .setStay(120)

AStages.addRestrictionForTag("optical_fabrication", "optical_fabrication", "astages:optical_fabrication")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('optical_fabrication')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lOptical Fabrication'))
    .setStay(120)
    
AStages.addRestrictionForTag("engraving", "engraving", "astages:engraving")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('engraving')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lEngraving'))
    .setStay(120)

AStages.addRestrictionForTag("airship_components", "airship_components", "astages:airship_components")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('airship_components')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lAirship Components'))
    .setStay(120)

AStages.addRestrictionForTag("astrophotography_gear", "astrophotography_gear", "astages:astrophotography_gear")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('astrophotography_gear')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lAstrophotography Gear'))
    .setStay(120)

AStages.addRestrictionForTag("mobile_packages", "mobile_packages", "astages:mobile_packages")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('mobile_packages')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lMobile Packages'))
    .setStay(120)

// ==================== Stage 8 ====================

AStages.customizeStage('stage8')
    .titleOnAdd(stage => Component.literal('§6§aStage 8 Unlocked'))
    .subTitleOnAdd(stage => Component.literal('§lNew Milestones are now available'))
    .setFadeIn(20) 
    .setFadeOut(20) 
    .setStay(180)

AStages.addRestrictionForTag("jetpack_mk2", "jetpack_mk2", "astages:jetpack_mk2")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('jetpack_mk2')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lNetherite Equipment'))
    .setStay(120)

AStages.addRestrictionForTag("spacecraft_components", "spacecraft_components", "astages:spacecraft_components")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('spacecraft_components')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lSpacecraft Components'))
    .setStay(120)

AStages.addRestrictionForTag("space_gear", "space_gear", "astages:space_gear")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('space_gear')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lSpace Gear'))
    .setStay(120)

AStages.addRestrictionForTag("atmospheric_machinery", "atmospheric_machinery", "astages:atmospheric_machinery")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('atmospheric_machinery')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lAtmospheric Machinery'))
    .setStay(120)

AStages.addRestrictionForTag("gyroscopic_components", "gyroscopic_components", "astages:gyroscopic_components")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('gyroscopic_components')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lGyroscopic Components'))
    .setStay(120)

AStages.addRestrictionForTag("rocket_propulsion", "rocket_propulsion", "astages:rocket_propulsion")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('rocket_propulsion')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lRocket Propulsion'))
    .setStay(120) 

// ==================== Stage 9 ====================

AStages.customizeStage('stage9')
    .titleOnAdd(stage => Component.literal('§6§aStage 9 Unlocked'))
    .subTitleOnAdd(stage => Component.literal('§lNew Milestones are now available'))
    .setFadeIn(20) 
    .setFadeOut(20) 
    .setStay(180)

AStages.addRestrictionForTag("nuclear_reactor_components", "nuclear_reactor_components", "astages:nuclear_reactor_components")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('nuclear_reactor_components')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lNuclear Reactor Components'))
    .setStay(120)

AStages.addRestrictionForTag("advanced_power_generation", "advanced_power_generation", "astages:advanced_power_generation")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('advanced_power_generation')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lAdvanced Power Generation'))
    .setStay(120)

AStages.addRestrictionForTag("lunar_spacecraft_components", "lunar_spacecraft_components", "astages:lunar_spacecraft_components")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('lunar_spacecraft_components')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lLunar Spacecraft Components'))
    .setStay(120)

AStages.addRestrictionForTag("lunar_atmospheric_machinery", "lunar_atmospheric_machinery", "astages:lunar_atmospheric_machinery")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('lunar_atmospheric_machinery')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lLunar Atmospheric Machinery'))
    .setStay(120)

AStages.addRestrictionForTag("martian_space_gear", "martian_space_gear", "astages:martian_space_gear")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('martian_space_gear')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lMartian Space Gear'))
    .setStay(120)

AStages.addRestrictionForTag("mechanical_companion", "mechanical_companion", "astages:mechanical_companion")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('mechanical_companion')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lAeronautics Automated Logistics'))
    .setStay(120)

// ==================== Stage 10 ====================

AStages.customizeStage('stage10')
    .titleOnAdd(stage => Component.literal('§6§aStage 10 Unlocked'))
    .subTitleOnAdd(stage => Component.literal('§lNew Milestones are now available'))
    .setFadeIn(20) 
    .setFadeOut(20) 
    .setStay(180)

AStages.addRestrictionForTag("createqol", "createqol", "astages:createqol")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('createqol')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lCreateqol'))
    .setStay(120)

AStages.addRestrictionForTag("teleportation", "teleportation", "astages:teleportation")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('teleportation')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§Teleportation'))
    .setStay(120)

AStages.addRestrictionForTag("pocket_dimension", "pocket_dimension", "astages:pocket_dimension")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('pocket_dimension')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lPocket Dimension'))
    .setStay(120)

AStages.addRestrictionForTag("advanced_teleportation", "advanced_teleportation", "astages:advanced_teleportation")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('advanced_teleportation')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lAdvanced Teleportation'))
    .setStay(120)

AStages.addRestrictionForTag("advanced_propulsion", "advanced_propulsion", "astages:advanced_propulsion")
    .globalShowName()
    .showInRecipeViewer()
AStages.customizeStage('advanced_propulsion')
    .titleOnAdd(stage => Component.literal('§6MILESTONE UNLOCKED'))
    .subTitleOnAdd(stage => Component.literal('§lAdvanced Propulsion'))
    .setStay(120) 

//////////////////////////////////////////////////////////////////

const CREATIVE_BYPASS_STAGES = [
    "copycats",
    "stage1",
    "diving_equipment_mk1",
    "machines_mk1",
    "rotational_power_generation_mk1",
    "contraptions_mk1",
    "rotational_power_transportation_mk1",
    "logistics_mk1",
    "stage2",
    "machines_mk2",
    "super_heating",
    "blueprints_mk1",
    "fluids_mk1",
    "advanced_redstone_mk1",
    "post_production",
    "stage3",
    "brass_production",
    "advanced_redstone_mk2",
    "better_item_managment",
    "advanced_fluids",
    "logistics_mk3",
    "moving_contraptions_mk2",
    "stage4",
    "steam_power_generation",
    "machines_mk4",
    "trains",
    "advanced_machining",
    "better_equipment",
    "vehicle_components",
    "economy",
    "stage5",
    "diesel_power_generation",
    "oil",
    "advanced_farming",
    "electricity",
    "hypertubes",
    "enchantment_industry",
    "stage6",
    "item_sink",
    "pattern_schematics",
    "jetpack_mk1",
    "chunk_loading",
    "cannons",
    "stage7",
    "automated_trading",
    "radar_components",
    "optical_fabrication",
    "engraving",
    "airship_components",
    "astrophotography_gear",
    "mobile_packages",
    "stage8",
    "jetpack_mk2",
    "spacecraft_components",
    "space_gear",
    "atmospheric_machinery",
    "gyroscopic_components",
    "rocket_propulsion",
    "stage9",
    "nuclear_reactor_components",
    "advanced_power_generation",
    "lunar_spacecraft_components",
    "lunar_atmospheric_machinery",
    "martian_space_gear",
    "mechanical_companion",
    "stage10",
    "createqol",
    "teleportation",
    "pocket_dimension",
    "advanced_teleportation",
    "advanced_propulsion"
]

console.info("CREATIVE WORLD UNLOCK LOADING")

const CREATIVE_WORLD_INITIALIZED = "creative_world_initialized"


PlayerEvents.loggedIn(event => {

    const player = event.player

    if (player.persistentData.getBoolean(CREATIVE_WORLD_INITIALIZED)) {
        return
    }
    
    player.persistentData.putBoolean(
        CREATIVE_WORLD_INITIALIZED,
        true
    )

    if (!player.isCreative()) {

        console.info(
            "[CREATIVE WORLD UNLOCK] " +
            player.username +
            " created/joined in SURVIVAL - no stages granted."
        )

        return
    }

    console.info(
        "[CREATIVE WORLD UNLOCK] " +
        player.username +
        " created/joined in CREATIVE!"
    )

    // Join message
    player.tell(
        "§6§lCreative World Detected!§r\n" +
        "§fAll stages have been §aunlocked §fbecause you joined this world in §eCreative Mode§f."
    )


    let addedStages = 0


    for (const stageName of CREATIVE_BYPASS_STAGES) {

        if (!AStages.playerHasStage(player, stageName)) {

            AStages.addStageToPlayer(
                player,
                stageName
            )

            addedStages++

            console.info(
                "[CREATIVE WORLD UNLOCK] ADDED: " +
                stageName
            )
        }
    }


    console.info(
        "[CREATIVE WORLD UNLOCK] COMPLETE - " +
        addedStages +
        " stages granted."
    )
})

//////////////////////////////////////////////////////////////////

ServerEvents.commandRegistry(event => {

    const { commands } = event

    event.register(
        commands.literal('unlockallstages')
            .requires(source => source.hasPermission(2))
            .executes(ctx => {

                const player = ctx.source.player

                if (!player) {
                    return 0
                }

                let addedStages = 0

                for (const stageName of CREATIVE_BYPASS_STAGES) {

                    if (!AStages.playerHasStage(player, stageName)) {

                        AStages.addStageToPlayer(
                            player,
                            stageName
                        )

                        addedStages++

                        console.info(
                            "[UNLOCK ALL STAGES] ADDED: " +
                            stageName +
                            " TO " +
                            player.username
                        )
                    }
                }

                player.tell(
                    "§6§lStages §8» §eUnlocked §6" +
                    addedStages +
                    " §estages!"
                )

                console.info(
                    "[UNLOCK ALL STAGES] " +
                    player.username +
                    " unlocked " +
                    addedStages +
                    " stages."
                )

                return 1
            })
    )
})