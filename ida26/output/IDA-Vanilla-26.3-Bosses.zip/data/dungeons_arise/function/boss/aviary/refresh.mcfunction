data modify entity @s data.period set value 11
effect clear @s minecraft:speed
data modify entity @s data.balance_version set value 2
attribute @s minecraft:attack_damage base set 4
